export const SUBJECTS = [
  'Mathematics',
  'Physics',
  'Chemistry',
  'Biology',
  'History',
  'Geography',
  'Computer Science',
  'English',
  'Economics',
  'Psychology'
];

export const STUDY_GOALS = [
  'Improve Grades',
  'Prepare for Competitive Exams',
  'Learn New Skills',
  'Better Time Management',
  'Master a Specific Subject'
];

export const CAREER_INTERESTS = [
  'Software Engineering',
  'Data Science',
  'Medicine',
  'Law',
  'Business & Entrepreneurship',
  'Arts & Design',
  'Teaching',
  'Research',
  'Finance',
  'Public Service'
];
