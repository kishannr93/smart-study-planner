import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Briefcase, Map, Star, TrendingUp, ChevronRight, Sparkles, ArrowLeft, ExternalLink, Building2, Wallet, Calendar, GraduationCap, LineChart, X } from 'lucide-react';
import { CareerPath, CareerDeepDive } from '@/src/types';
import { cn } from '@/src/lib/utils';
import { geminiService } from '@/src/services/geminiService';
import { toast } from 'sonner';

interface CareerProps {
  careerPaths: CareerPath[];
  onGetAdvice: () => void;
  onBack: () => void;
}

export default function Career({ careerPaths, onGetAdvice, onBack }: CareerProps) {
  const [selectedPath, setSelectedPath] = useState<CareerPath | null>(null);
  const [deepDive, setDeepDive] = useState<CareerDeepDive | null>(null);
  const [isDeepDiving, setIsDeepDiving] = useState(false);

  const handleDeepDive = async (path: CareerPath) => {
    setSelectedPath(path);
    setIsDeepDiving(true);
    setDeepDive(null);
    
    try {
      const data = await geminiService.getCareerDeepDive(path.title);
      setDeepDive(data);
    } catch (error) {
      toast.error("Failed to get deep dive data. Please try again.");
      setSelectedPath(null);
    } finally {
      setIsDeepDiving(false);
    }
  };

  return (
    <div className="p-6 space-y-8 relative min-h-full">
      <header className="space-y-4">
        <div className="flex items-center gap-3">
          <button 
            onClick={onBack}
            className="p-2 hover:bg-slate-100 rounded-xl text-slate-500 transition-colors"
          >
            <ArrowLeft size={20} />
          </button>
          <h1 className="text-2xl font-bold tracking-tight">Career Assistant</h1>
        </div>
        <p className="text-slate-500 text-sm leading-relaxed">
          Discover personalized career paths based on your skills and interests.
        </p>
      </header>

      <motion.button
        whileTap={{ scale: 0.98 }}
        onClick={onGetAdvice}
        className="w-full bg-gradient-to-r from-indigo-600 to-purple-600 text-white p-6 rounded-3xl shadow-xl shadow-indigo-200 flex items-center justify-between group"
      >
        <div className="flex items-center gap-4">
          <div className="w-12 h-12 bg-white/20 rounded-2xl flex items-center justify-center backdrop-blur-sm">
            <Sparkles size={24} />
          </div>
          <div className="text-left">
            <h3 className="font-bold">Get AI Career Advice</h3>
            <p className="text-xs opacity-80">Personalized roadmap for you</p>
          </div>
        </div>
        <ChevronRight size={20} className="group-hover:translate-x-1 transition-transform" />
      </motion.button>

      <section className="space-y-4">
        <h2 className="text-lg font-semibold flex items-center gap-2">
          <TrendingUp size={20} className="text-indigo-600" />
          Recommended Paths
        </h2>

        <div className="space-y-4">
          {careerPaths.length === 0 ? (
            <div className="text-center py-12 bg-white rounded-3xl border border-dashed border-slate-200">
              <Briefcase className="mx-auto text-slate-300 mb-2" size={32} />
              <p className="text-slate-400 text-sm">No career paths generated yet.</p>
            </div>
          ) : (
            careerPaths.map((path, idx) => (
              <motion.div
                key={path.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: idx * 0.1 }}
                className="bg-white p-6 rounded-3xl shadow-sm border border-slate-100 space-y-4"
              >
                <div className="flex justify-between items-start">
                  <div className="space-y-1">
                    <h3 className="font-bold text-lg text-slate-800">{path.title}</h3>
                    <p className="text-xs text-slate-500 leading-relaxed">{path.description}</p>
                  </div>
                  {path.trending && (
                    <span className="bg-amber-100 text-amber-700 text-[10px] font-bold px-2 py-1 rounded-full uppercase tracking-wider">
                      Trending
                    </span>
                  )}
                </div>

                <div className="space-y-3">
                  <h4 className="text-[10px] font-bold uppercase tracking-widest text-slate-400">Roadmap</h4>
                  <div className="space-y-2">
                    {path.roadmap.map((step, sIdx) => (
                      <div key={sIdx} className="flex items-center gap-3">
                        <div className="w-5 h-5 rounded-full bg-indigo-50 text-indigo-600 flex items-center justify-center text-[10px] font-bold">
                          {sIdx + 1}
                        </div>
                        <span className="text-xs text-slate-600 font-medium">{step}</span>
                      </div>
                    ))}
                  </div>
                </div>

                <div className="pt-2 flex flex-wrap gap-2">
                  {path.requiredSkills.map((skill, sIdx) => (
                    <span key={sIdx} className="bg-slate-50 text-slate-500 text-[10px] font-semibold px-2 py-1 rounded-md border border-slate-100">
                      {skill}
                    </span>
                  ))}
                </div>

                <button
                  onClick={() => handleDeepDive(path)}
                  className="w-full mt-4 bg-slate-900 text-white py-3 rounded-2xl text-xs font-bold flex items-center justify-center gap-2 hover:bg-slate-800 transition-colors"
                >
                  <Sparkles size={14} />
                  Deep Dive Analysis
                </button>
              </motion.div>
            ))
          )}
        </div>
      </section>

      {/* Deep Dive Modal */}
      <AnimatePresence>
        {selectedPath && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/60 backdrop-blur-sm z-[60] flex items-center justify-center p-4"
          >
            <motion.div
              initial={{ scale: 0.9, opacity: 0, y: 20 }}
              animate={{ scale: 1, opacity: 1, y: 0 }}
              exit={{ scale: 0.9, opacity: 0, y: 20 }}
              className="bg-white w-full max-w-2xl max-h-[90vh] overflow-y-auto rounded-[2.5rem] shadow-2xl relative"
            >
              <button 
                onClick={() => setSelectedPath(null)}
                className="absolute right-6 top-6 p-2 hover:bg-slate-100 rounded-full text-slate-400 transition-colors z-10"
              >
                <X size={24} />
              </button>

              <div className="p-8 space-y-8">
                <header className="space-y-2 pr-12">
                  <h2 className="text-3xl font-black tracking-tight text-slate-900">{selectedPath.title}</h2>
                  <p className="text-slate-500 text-sm leading-relaxed">{selectedPath.description}</p>
                </header>

                {isDeepDiving ? (
                  <div className="py-20 flex flex-col items-center justify-center space-y-4">
                    <div className="w-12 h-12 border-4 border-indigo-600 border-t-transparent rounded-full animate-spin" />
                    <p className="text-slate-500 font-medium animate-pulse">AI is performing deep analysis...</p>
                  </div>
                ) : deepDive ? (
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div className="space-y-6">
                      <section className="bg-emerald-50 p-5 rounded-3xl border border-emerald-100">
                        <div className="flex items-center gap-3 mb-3 text-emerald-700">
                          <Wallet size={20} />
                          <h4 className="font-bold text-sm uppercase tracking-wider">Salary Range</h4>
                        </div>
                        <p className="text-2xl font-black text-emerald-900">{deepDive.salaryRange}</p>
                      </section>

                      <section className="bg-indigo-50 p-5 rounded-3xl border border-indigo-100">
                        <div className="flex items-center gap-3 mb-3 text-indigo-700">
                          <Calendar size={20} />
                          <h4 className="font-bold text-sm uppercase tracking-wider">Day-to-Day</h4>
                        </div>
                        <ul className="space-y-2">
                          {deepDive.dayToDay.map((task, i) => (
                            <li key={i} className="text-xs text-indigo-900 flex gap-2">
                              <span className="text-indigo-400 mt-1">•</span>
                              {task}
                            </li>
                          ))}
                        </ul>
                      </section>

                      <section className="bg-slate-50 p-5 rounded-3xl border border-slate-100">
                        <div className="flex items-center gap-3 mb-3 text-slate-700">
                          <Building2 size={20} />
                          <h4 className="font-bold text-sm uppercase tracking-wider">Top Companies</h4>
                        </div>
                        <div className="flex flex-wrap gap-2">
                          {deepDive.topCompanies.map((company, i) => (
                            <span key={i} className="bg-white px-3 py-1.5 rounded-xl text-[10px] font-bold text-slate-600 border border-slate-200">
                              {company}
                            </span>
                          ))}
                        </div>
                      </section>
                    </div>

                    <div className="space-y-6">
                      <section className="bg-purple-50 p-5 rounded-3xl border border-purple-100">
                        <div className="flex items-center gap-3 mb-3 text-purple-700">
                          <GraduationCap size={20} />
                          <h4 className="font-bold text-sm uppercase tracking-wider">Certifications</h4>
                        </div>
                        <ul className="space-y-2">
                          {deepDive.certifications.map((cert, i) => (
                            <li key={i} className="text-xs text-purple-900 flex gap-2">
                              <span className="text-purple-400 mt-1">•</span>
                              {cert}
                            </li>
                          ))}
                        </ul>
                      </section>

                      <section className="bg-amber-50 p-5 rounded-3xl border border-amber-100">
                        <div className="flex items-center gap-3 mb-3 text-amber-700">
                          <LineChart size={20} />
                          <h4 className="font-bold text-sm uppercase tracking-wider">Future Outlook</h4>
                        </div>
                        <p className="text-xs text-amber-900 leading-relaxed">{deepDive.futureOutlook}</p>
                      </section>

                      <section className="bg-blue-50 p-5 rounded-3xl border border-blue-100">
                        <div className="flex items-center gap-3 mb-3 text-blue-700">
                          <ExternalLink size={20} />
                          <h4 className="font-bold text-sm uppercase tracking-wider">Learning Resources</h4>
                        </div>
                        <div className="space-y-2">
                          {deepDive.learningResources.map((res, i) => (
                            <a 
                              key={i} 
                              href={res.url} 
                              target="_blank" 
                              rel="noopener noreferrer"
                              className="block p-2 bg-white rounded-xl text-[10px] font-bold text-blue-600 border border-blue-200 hover:bg-blue-600 hover:text-white transition-all"
                            >
                              {res.title}
                            </a>
                          ))}
                        </div>
                      </section>
                    </div>
                  </div>
                ) : null}
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
