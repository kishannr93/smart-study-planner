import React from 'react';
import { Sparkles, Search, Monitor, User as UserIcon } from 'lucide-react';
import { cn } from '@/src/lib/utils';

interface LayoutProps {
  children: React.ReactNode;
  activeTab: string;
  setActiveTab: (tab: string) => void;
  userName?: string;
  onLogout?: () => void;
}

export default function Layout({ children, activeTab, setActiveTab, userName, onLogout }: LayoutProps) {
  const initials = userName ? userName.split(' ').map(n => n[0]).join('').toUpperCase().substring(0, 2) : 'U';

  return (
    <div className="min-h-screen bg-brand-bg text-white font-sans">
      {/* Top Navigation Bar */}
      <header className="h-16 border-b border-brand-border flex items-center justify-between px-6 sticky top-0 bg-brand-bg z-50">
        <button 
          onClick={() => setActiveTab('home')}
          className="flex items-center gap-2 hover:opacity-80 transition-opacity"
        >
          <div className="w-8 h-8 bg-brand-accent rounded-lg flex items-center justify-center">
            <Sparkles size={18} className="text-white" />
          </div>
          <span className="font-bold text-lg tracking-tight">Smart Study Plan</span>
        </button>

        <div className="flex-1 max-w-xl mx-8 relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-brand-text-muted" size={16} />
          <input 
            type="text" 
            placeholder="Search tools & features..." 
            className="w-full bg-brand-card border border-brand-border rounded-full py-2 pl-10 pr-4 text-sm focus:outline-none focus:ring-1 focus:ring-brand-accent transition-all"
          />
        </div>

        <div className="flex items-center gap-4">
          <div className="flex items-center gap-3 pl-4 border-l border-brand-border">
            <button 
              onClick={() => setActiveTab('profile')}
              className="flex items-center gap-2 hover:opacity-80 transition-opacity"
            >
              <div className="w-8 h-8 bg-indigo-500 rounded-full flex items-center justify-center text-xs font-bold">
                {initials}
              </div>
              <span className="text-sm font-medium">{userName || 'User'}</span>
            </button>
            
            {onLogout && (
              <button 
                onClick={onLogout}
                className="text-xs font-bold uppercase tracking-wider text-brand-text-muted hover:text-rose-400 transition-colors ml-2"
              >
                Logout
              </button>
            )}
          </div>
        </div>
      </header>

      <main className="pb-12">
        {children}
      </main>
    </div>
  );
}
