import React from 'react';
import { motion } from 'motion/react';
import { 
  Map, 
  BookOpen, 
  MessageSquare, 
  FileText, 
  Lightbulb, 
  Gamepad2, 
  Star,
  Monitor,
  Code2,
  ChevronRight
} from 'lucide-react';
import { cn } from '@/src/lib/utils';

interface DashboardProps {
  onSelectTool: (tab: string) => void;
}

export default function Dashboard({ onSelectTool }: DashboardProps) {
  const tools = [
    { id: 'career', icon: Map, title: 'Career Roadmap', desc: 'Generate a personalized career plan.', color: 'text-indigo-400', bg: 'bg-indigo-400/10' },
    { id: 'notes', icon: BookOpen, title: 'Learning Hub', desc: 'Find curated learning resources for any skill.', color: 'text-blue-400', bg: 'bg-blue-400/10' },
    { id: 'chat', icon: MessageSquare, title: 'Mock Interview', desc: 'Practice with an AI interviewer.', color: 'text-indigo-400', bg: 'bg-indigo-400/10' },
    { id: 'planner', icon: Lightbulb, title: 'Project Ideas', desc: 'Discover projects to build your portfolio.', color: 'text-indigo-400', bg: 'bg-indigo-400/10' },
    { id: 'practice', icon: Gamepad2, title: 'Career Quest Mode', desc: 'Gamify your career journey.', color: 'text-blue-400', bg: 'bg-blue-400/10' },
  ];

  return (
    <div className="max-w-7xl mx-auto px-6 py-8 space-y-10">
      {/* Hero Section */}
      <motion.section 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="relative overflow-hidden bg-gradient-to-br from-[#1E1B4B] to-[#161B22] rounded-3xl p-10 border border-brand-border"
      >
        <div className="relative z-10 max-w-2xl space-y-6">
          <h1 className="text-4xl font-bold tracking-tight sm:text-5xl">
            Unlock Your Career Potential
          </h1>
          <p className="text-brand-text-muted text-lg leading-relaxed">
            Let our AI build a personalized roadmap to guide you toward your professional goals.
          </p>
          <button 
            onClick={() => onSelectTool('career')}
            className="bg-brand-accent hover:bg-brand-accent/90 text-white px-8 py-3 rounded-xl font-bold transition-all shadow-lg shadow-brand-accent/20"
          >
            Generate My Roadmap
          </button>
        </div>

        {/* Decorative Illustration (Abstract Line Art) */}
        <div className="absolute right-10 top-1/2 -translate-y-1/2 opacity-20 pointer-events-none">
          <svg width="240" height="240" viewBox="0 0 240 240" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M40 120C40 75.8172 75.8172 40 120 40C164.183 40 200 75.8172 200 120C200 164.183 164.183 200 120 200" stroke="white" strokeWidth="8" strokeLinecap="round"/>
            <path d="M120 120L180 60" stroke="white" strokeWidth="8" strokeLinecap="round"/>
            <circle cx="120" cy="120" r="12" fill="white"/>
          </svg>
        </div>
      </motion.section>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {[
          { icon: Code2, label: 'Top Skill', value: 'HTML/CSS', color: 'text-blue-400' },
          { icon: Star, label: 'Primary Interest', value: 'Web Development', color: 'text-amber-400' },
          { icon: Monitor, label: 'Experience', value: '3rd Year', color: 'text-emerald-400' },
        ].map((stat, idx) => (
          <motion.div
            key={stat.label}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 * idx }}
            className="bg-brand-card border border-brand-border p-6 rounded-2xl flex items-center gap-4 hover:border-brand-accent/50 transition-colors group cursor-pointer"
          >
            <div className={cn("w-12 h-12 rounded-xl bg-brand-bg flex items-center justify-center border border-brand-border group-hover:scale-110 transition-transform", stat.color)}>
              <stat.icon size={24} />
            </div>
            <div>
              <p className="text-brand-text-muted text-xs font-bold uppercase tracking-wider">{stat.label}</p>
              <p className="text-lg font-bold">{stat.value}</p>
            </div>
          </motion.div>
        ))}
      </div>

      {/* Tools Section */}
      <section className="space-y-6">
        <h2 className="text-2xl font-bold tracking-tight">Explore Your Tools</h2>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {tools.map((tool, idx) => (
            <motion.div
              key={tool.title}
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ delay: 0.05 * idx }}
              onClick={() => onSelectTool(tool.id)}
              className="bg-brand-card border border-brand-border p-5 rounded-2xl hover:border-brand-accent/50 transition-all group cursor-pointer hover:-translate-y-1"
            >
              <div className="flex items-start justify-between mb-4">
                <div className={cn("w-10 h-10 rounded-lg flex items-center justify-center", tool.bg, tool.color)}>
                  <tool.icon size={20} />
                </div>
                <ChevronRight size={16} className="text-brand-text-muted group-hover:text-white transition-colors" />
              </div>
              <h3 className="font-bold text-sm mb-1">{tool.title}</h3>
              <p className="text-brand-text-muted text-xs leading-relaxed">
                {tool.desc}
              </p>
            </motion.div>
          ))}
        </div>
      </section>
    </div>
  );
}
