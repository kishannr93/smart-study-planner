import React from 'react';
import { motion } from 'motion/react';
import { Sparkles, ShieldCheck, Zap } from 'lucide-react';

interface LoginProps {
  onLogin: () => void;
  isLoading: boolean;
}

export default function Login({ onLogin, isLoading }: LoginProps) {
  return (
    <div className="min-h-screen bg-brand-bg flex flex-col items-center justify-center p-6 relative overflow-hidden text-white">
      {/* Decorative background elements */}
      <div className="absolute top-[-10%] left-[-10%] w-96 h-96 bg-brand-accent rounded-full blur-[120px] opacity-20 animate-pulse" />
      <div className="absolute bottom-[-10%] right-[-10%] w-96 h-96 bg-indigo-500 rounded-full blur-[120px] opacity-20 animate-pulse [animation-delay:1s]" />

      <motion.div 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="w-full max-w-sm space-y-12 relative z-10"
      >
        <div className="flex flex-col items-center text-center space-y-6">
          <div className="w-20 h-20 bg-brand-accent rounded-2xl flex items-center justify-center text-white shadow-2xl shadow-brand-accent/20 rotate-12">
            <Sparkles size={40} />
          </div>
          <div className="space-y-2">
            <h1 className="text-4xl font-black tracking-tight">Smart Study Plan</h1>
            <p className="text-brand-text-muted text-sm font-medium">Unlock Your Professional Potential</p>
          </div>
        </div>

        <div className="space-y-4">
          <motion.button
            whileHover={{ scale: 1.02 }}
            whileTap={{ scale: 0.98 }}
            onClick={onLogin}
            disabled={isLoading}
            className="w-full bg-white text-slate-900 p-4 rounded-2xl shadow-xl flex items-center justify-center gap-3 hover:bg-slate-50 transition-all group"
          >
            <div className="w-6 h-6 flex items-center justify-center">
              <svg viewBox="0 0 24 24" className="w-5 h-5">
                <path d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" fill="#4285F4" />
                <path d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" fill="#34A853" />
                <path d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z" fill="#FBBC05" />
                <path d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z" fill="#EA4335" />
              </svg>
            </div>
            <span className="text-sm font-bold">Continue with Google</span>
          </motion.button>
        </div>

        <div className="grid grid-cols-2 gap-4">
          <div className="p-4 bg-brand-card rounded-2xl border border-brand-border space-y-1">
            <Zap size={16} className="text-brand-accent" />
            <h3 className="text-[10px] font-bold uppercase text-brand-text-muted">AI Powered</h3>
            <p className="text-[11px] text-white font-medium leading-tight">Personalized roadmaps & insights</p>
          </div>
          <div className="p-4 bg-brand-card rounded-2xl border border-brand-border space-y-1">
            <ShieldCheck size={16} className="text-indigo-400" />
            <h3 className="text-[10px] font-bold uppercase text-brand-text-muted">Secure</h3>
            <p className="text-[11px] text-white font-medium leading-tight">Your data is private & safe</p>
          </div>
        </div>
      </motion.div>

      <footer className="absolute bottom-8 text-center space-y-1">
        <p className="text-[10px] text-brand-text-muted font-bold uppercase tracking-widest">Version 2.0.0</p>
        <p className="text-[10px] text-brand-text-muted">© 2026 Smart Study Plan</p>
      </footer>
    </div>
  );
}
