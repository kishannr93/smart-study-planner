import React, { useState } from 'react';
import { motion } from 'motion/react';
import { Plus, Calendar as CalendarIcon, ChevronLeft, ChevronRight, ArrowLeft } from 'lucide-react';
import { format, startOfToday, addDays, startOfWeek, eachDayOfInterval, isSameDay } from 'date-fns';
import { cn } from '@/src/lib/utils';
import { StudyTask } from '@/src/types';

interface PlannerProps {
  tasks: StudyTask[];
  onAddTask: (task: Partial<StudyTask>) => void;
  onBack: () => void;
}

export default function Planner({ tasks, onAddTask, onBack }: PlannerProps) {
  const [selectedDate, setSelectedDate] = useState(startOfToday());
  const weekStart = startOfWeek(selectedDate);
  const weekDays = eachDayOfInterval({
    start: weekStart,
    end: addDays(weekStart, 6)
  });

  const dayTasks = tasks.filter(t => isSameDay(new Date(t.deadline), selectedDate));

  return (
    <div className="p-6 space-y-6">
      <header className="flex justify-between items-center">
        <div className="flex items-center gap-3">
          <button 
            onClick={onBack}
            className="p-2 hover:bg-slate-100 rounded-xl text-slate-500 transition-colors"
          >
            <ArrowLeft size={20} />
          </button>
          <h1 className="text-2xl font-bold tracking-tight">Study Planner</h1>
        </div>
        <button 
          onClick={() => onAddTask({ deadline: selectedDate.toISOString() })}
          className="bg-indigo-600 text-white p-2 rounded-xl shadow-lg shadow-indigo-200"
        >
          <Plus size={20} />
        </button>
      </header>

      <div className="bg-white p-4 rounded-3xl shadow-sm border border-slate-100 space-y-4">
        <div className="flex justify-between items-center px-2">
          <h2 className="font-semibold text-slate-700">{format(selectedDate, 'MMMM yyyy')}</h2>
          <div className="flex gap-2">
            <button onClick={() => setSelectedDate(addDays(selectedDate, -7))} className="p-1 hover:bg-slate-50 rounded-lg">
              <ChevronLeft size={20} className="text-slate-400" />
            </button>
            <button onClick={() => setSelectedDate(addDays(selectedDate, 7))} className="p-1 hover:bg-slate-50 rounded-lg">
              <ChevronRight size={20} className="text-slate-400" />
            </button>
          </div>
        </div>

        <div className="flex justify-between">
          {weekDays.map((day) => {
            const isSelected = isSameDay(day, selectedDate);
            const isToday = isSameDay(day, startOfToday());
            return (
              <button
                key={day.toString()}
                onClick={() => setSelectedDate(day)}
                className={cn(
                  "flex flex-col items-center p-2 rounded-2xl transition-all duration-200 w-10",
                  isSelected ? "bg-indigo-600 text-white shadow-md shadow-indigo-100 scale-110" : "text-slate-400 hover:bg-slate-50"
                )}
              >
                <span className="text-[10px] font-bold uppercase mb-1">{format(day, 'EEE')}</span>
                <span className="text-sm font-bold">{format(day, 'd')}</span>
                {isToday && !isSelected && <div className="w-1 h-1 bg-indigo-600 rounded-full mt-1" />}
              </button>
            );
          })}
        </div>
      </div>

      <section className="space-y-4">
        <h3 className="font-semibold text-slate-700 px-1">Schedule for {format(selectedDate, 'MMM d')}:</h3>
        <div className="space-y-3">
          {dayTasks.length === 0 ? (
            <div className="text-center py-12 bg-slate-50 rounded-3xl border border-dashed border-slate-200">
              <CalendarIcon className="mx-auto text-slate-300 mb-2" size={32} />
              <p className="text-slate-400 text-sm">No study sessions planned.</p>
            </div>
          ) : (
            dayTasks.map((task, idx) => (
              <motion.div
                key={task.id}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: idx * 0.05 }}
                className="bg-white p-4 rounded-2xl shadow-sm border border-slate-100 flex items-center gap-4"
              >
                <div className="w-1 h-10 bg-indigo-600 rounded-full" />
                <div className="flex-1">
                  <h4 className="font-medium text-sm">{task.title}</h4>
                  <p className="text-[10px] text-slate-400 font-medium uppercase tracking-wider">{task.subject}</p>
                </div>
                <div className="text-right">
                  <p className="text-xs font-bold text-slate-600">{format(new Date(task.deadline), 'h:mm a')}</p>
                </div>
              </motion.div>
            ))
          )}
        </div>
      </section>
    </div>
  );
}
