import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Brain, ChevronRight, CheckCircle2, XCircle, Award, Sparkles, ArrowLeft } from 'lucide-react';
import { Quiz } from '@/src/types';
import { cn } from '@/src/lib/utils';

interface QuizSectionProps {
  quizzes: Quiz[];
  onGenerateQuiz: (subject: string) => void;
  onBack: () => void;
}

export default function QuizSection({ quizzes, onGenerateQuiz, onBack }: QuizSectionProps) {
  const [currentQuiz, setCurrentQuiz] = useState<Quiz | null>(null);
  const [currentQuestionIdx, setCurrentQuestionIdx] = useState(0);
  const [selectedOption, setSelectedOption] = useState<number | null>(null);
  const [score, setScore] = useState(0);
  const [showResult, setShowResult] = useState(false);
  const [subject, setSubject] = useState('');

  const handleQuizStart = (quiz: Quiz) => {
    setCurrentQuiz(quiz);
    setCurrentQuestionIdx(0);
    setSelectedOption(null);
    setScore(0);
    setShowResult(false);
  };

  const handleOptionSelect = (idx: number) => {
    if (selectedOption !== null) return;
    setSelectedOption(idx);
    if (idx === currentQuiz?.questions[currentQuestionIdx].correctAnswer) {
      setScore(prev => prev + 1);
    }
  };

  const handleNext = () => {
    if (currentQuiz && currentQuestionIdx < currentQuiz.questions.length - 1) {
      setCurrentQuestionIdx(prev => prev + 1);
      setSelectedOption(null);
    } else {
      setShowResult(true);
    }
  };

  const handleGlobalBack = () => {
    if (currentQuiz || showResult) {
      setCurrentQuiz(null);
      setShowResult(false);
    } else {
      onBack();
    }
  };

  return (
    <div className="p-6 space-y-8 bg-white text-black min-h-full">
      <header className="space-y-4">
        <div className="space-y-2">
          <div className="flex items-center gap-3">
            <button 
              onClick={handleGlobalBack}
              className="p-2 hover:bg-slate-100 rounded-xl text-slate-500 transition-colors"
            >
              <ArrowLeft size={20} />
            </button>
            <h1 className="text-2xl font-bold tracking-tight">Practice Zone</h1>
          </div>
        </div>

        {!currentQuiz && !showResult && (
          <div className="space-y-2">
            <label htmlFor="subject-input" className="text-[10px] font-bold uppercase tracking-widest text-slate-400 px-2">
              Target Subject (Optional)
            </label>
            <input
              id="subject-input"
              type="text"
              placeholder="e.g. Physics, History, JavaScript..."
              value={subject}
              onChange={(e) => setSubject(e.target.value)}
              className="w-full bg-white border border-slate-100 rounded-2xl py-3 px-4 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500/20 transition-all shadow-sm"
            />
          </div>
        )}
      </header>

      {currentQuiz && !showResult ? (
        <motion.div 
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          className="bg-white p-6 rounded-3xl shadow-sm border border-slate-100 space-y-6"
        >
          <div className="flex justify-between items-center">
            <span className="text-[10px] font-bold uppercase tracking-widest text-indigo-500">
              Question {currentQuestionIdx + 1} of {currentQuiz.questions.length}
            </span>
            <button onClick={() => setCurrentQuiz(null)} className="text-slate-400 hover:text-slate-600">
              <XCircle size={20} />
            </button>
          </div>

          <h3 className="text-lg font-bold text-black leading-relaxed">
            {currentQuiz.questions[currentQuestionIdx].question}
          </h3>

          <div className="space-y-3">
            {currentQuiz.questions[currentQuestionIdx].options.map((option, idx) => {
              const isSelected = selectedOption === idx;
              const isCorrect = idx === currentQuiz.questions[currentQuestionIdx].correctAnswer;
              const showCorrect = selectedOption !== null && isCorrect;
              const showWrong = selectedOption !== null && isSelected && !isCorrect;

              return (
                <button
                  key={idx}
                  onClick={() => handleOptionSelect(idx)}
                  disabled={selectedOption !== null}
                  className={cn(
                    "w-full p-4 rounded-2xl text-left text-sm font-medium transition-all border-2",
                    !selectedOption ? "bg-slate-50 border-transparent hover:border-indigo-200 text-black" : 
                    showCorrect ? "bg-emerald-50 border-emerald-500 text-emerald-900" :
                    showWrong ? "bg-rose-50 border-rose-500 text-rose-900" :
                    "bg-slate-50 border-transparent opacity-50 text-black"
                  )}
                >
                  <div className="flex justify-between items-center">
                    <span>{option}</span>
                    {showCorrect && <CheckCircle2 size={18} />}
                    {showWrong && <XCircle size={18} />}
                  </div>
                </button>
              );
            })}
          </div>

          {selectedOption !== null && (
            <motion.div 
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              className="space-y-4"
            >
              <div className="p-4 bg-indigo-50 rounded-2xl text-xs text-indigo-700 leading-relaxed italic">
                <strong>Explanation:</strong> {currentQuiz.questions[currentQuestionIdx].explanation}
              </div>
              <button
                onClick={handleNext}
                className="w-full bg-indigo-600 text-black py-4 rounded-2xl font-bold shadow-lg shadow-indigo-100"
              >
                {currentQuestionIdx < currentQuiz.questions.length - 1 ? 'Next Question' : 'Finish Quiz'}
              </button>
            </motion.div>
          )}
        </motion.div>
      ) : showResult ? (
        <motion.div 
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          className="bg-white p-8 rounded-3xl shadow-sm border border-slate-100 text-center space-y-6"
        >
          <div className="w-20 h-20 bg-indigo-100 rounded-full flex items-center justify-center mx-auto text-indigo-600">
            <Award size={40} />
          </div>
          <div className="space-y-2">
            <h3 className="text-2xl font-bold">Quiz Completed!</h3>
            <p className="text-slate-500">You scored {score} out of {currentQuiz?.questions.length}</p>
          </div>
          <div className="text-4xl font-black text-indigo-600">
            {Math.round((score / (currentQuiz?.questions.length || 1)) * 100)}%
          </div>
          <button
            onClick={() => setCurrentQuiz(null)}
            className="w-full bg-indigo-600 text-black py-4 rounded-2xl font-bold shadow-lg shadow-indigo-100"
          >
            Back to Practice
          </button>
        </motion.div>
      ) : (
        <div className="space-y-6">
          <div className="grid grid-cols-1 gap-4">
            <button 
              onClick={() => onGenerateQuiz(subject || 'General')}
              className="bg-indigo-600 text-black p-6 rounded-3xl shadow-xl shadow-indigo-100 flex items-center justify-between group"
            >
              <div className="flex items-center gap-4 text-left">
                <div className="w-12 h-12 bg-white/20 rounded-2xl flex items-center justify-center">
                  <Brain size={24} />
                </div>
                <div>
                  <h3 className="font-bold">Quiz from Discussions</h3>
                  <p className="text-[10px] opacity-80">Personalized quiz based on your chats & notes</p>
                </div>
              </div>
              <Sparkles size={20} className="group-hover:rotate-12 transition-transform" />
            </button>
          </div>

          <section className="space-y-4">
            <h2 className="text-sm font-bold uppercase tracking-widest text-slate-400 px-2">
              Recent Quizzes
            </h2>
            
            <div className="space-y-3">
              {quizzes.length === 0 ? (
                <div className="text-center py-12 bg-white rounded-3xl border border-dashed border-slate-200">
                  <p className="text-slate-400 text-sm">No quizzes yet.</p>
                </div>
              ) : (
                quizzes.map((quiz) => (
                  <button
                    key={quiz.id}
                    onClick={() => handleQuizStart(quiz)}
                    className="w-full bg-white p-4 rounded-2xl shadow-sm border border-slate-100 flex items-center justify-between hover:bg-slate-50 transition-colors"
                  >
                    <div className="flex items-center gap-4">
                      <div className="w-10 h-10 bg-indigo-50 text-indigo-600 rounded-xl flex items-center justify-center">
                        <Brain size={20} />
                      </div>
                      <div className="text-left">
                        <h4 className="font-bold text-sm text-black">{quiz.title}</h4>
                        <p className="text-[10px] text-black uppercase font-bold">{quiz.subject}</p>
                      </div>
                    </div>
                    <ChevronRight size={18} className="text-slate-300" />
                  </button>
                ))
              )}
            </div>
          </section>
        </div>
      )}
    </div>
  );
}
