import React, { useState } from 'react';
import { motion } from 'motion/react';
import { User, Settings, LogOut, Award, Book, Target, ChevronRight, Save, Phone, Mail, Building2, Clock, CheckCircle2, Zap, BarChart3, ArrowLeft } from 'lucide-react';
import { UserProfile, StudyTask } from '@/src/types';

interface ProfileProps {
  user: UserProfile;
  tasks: StudyTask[];
  onLogout: () => void;
  onUpdateProfile: (updates: Partial<UserProfile>) => Promise<void>;
  onBack: () => void;
}

export default function Profile({ user, tasks, onLogout, onUpdateProfile, onBack }: ProfileProps) {
  const [isEditing, setIsEditing] = useState(false);
  const [formData, setFormData] = useState({
    displayName: user.displayName,
    phone: user.phone || '',
    email: user.email,
    branch: user.branch || ''
  });

  const stats = [
    { label: 'Streak', value: `${user.streak} Days`, icon: Award, color: 'text-amber-500', bg: 'bg-amber-50' },
    { label: 'Goals', value: user.studyGoals.length, icon: Target, color: 'text-indigo-500', bg: 'bg-indigo-50' },
    { label: 'Interests', value: user.interests.length, icon: Book, color: 'text-emerald-500', bg: 'bg-emerald-50' },
  ];

  const handleSave = async () => {
    await onUpdateProfile(formData);
    setIsEditing(false);
  };

  const completedTasks = tasks.filter(t => t.completed).length;

  return (
    <div className="max-w-4xl mx-auto p-6 space-y-8">
      <div className="flex justify-start">
        <button 
          onClick={onBack}
          className="p-2 hover:bg-white/10 rounded-xl text-white/70 transition-colors flex items-center gap-2 text-sm font-medium"
        >
          <ArrowLeft size={20} />
          Back to Home
        </button>
      </div>
      <header className="flex flex-col items-center text-center space-y-4">
        <div className="relative">
          <div className="w-24 h-24 rounded-full border-4 border-white shadow-xl overflow-hidden bg-indigo-100 flex items-center justify-center">
            {user.photoURL ? (
              <img src={user.photoURL} alt={user.displayName} className="w-full h-full object-cover" referrerPolicy="no-referrer" />
            ) : (
              <User size={48} className="text-indigo-300" />
            )}
          </div>
          <button 
            onClick={() => setIsEditing(!isEditing)}
            className="absolute bottom-0 right-0 w-8 h-8 bg-brand-accent rounded-full border-4 border-brand-bg flex items-center justify-center text-white hover:scale-110 transition-transform"
          >
            <Settings size={14} />
          </button>
        </div>
        <div>
          <h1 className="text-2xl font-bold text-white">{user.displayName}</h1>
          <p className="text-sm text-brand-text-muted">{user.email}</p>
        </div>
      </header>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {stats.map((stat, idx) => {
          const Icon = stat.icon;
          return (
            <motion.div
              key={stat.label}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: idx * 0.1 }}
              className="bg-brand-card p-6 rounded-3xl border border-brand-border flex flex-col items-center space-y-3"
            >
              <div className={cn("p-3 rounded-2xl", stat.bg, stat.color)}>
                <Icon size={24} />
              </div>
              <div className="text-center">
                <div className="text-xl font-bold text-white">{stat.value}</div>
                <div className="text-xs font-bold uppercase text-brand-text-muted tracking-wider">{stat.label}</div>
              </div>
            </motion.div>
          );
        })}
      </div>

      <div className="space-y-6">
        <h2 className="text-sm font-bold uppercase tracking-widest text-brand-text-muted px-2">Dashboard Overview</h2>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          {[
            { label: 'Study Hours', value: `${user.studyHours || 0}h`, icon: Clock, color: 'text-blue-400', bg: 'bg-blue-400/10' },
            { label: 'Tasks Done', value: completedTasks, icon: CheckCircle2, color: 'text-emerald-400', bg: 'bg-emerald-400/10' },
            { label: 'Current Streak', value: `${user.streak}d`, icon: Zap, color: 'text-amber-400', bg: 'bg-amber-400/10' },
            { label: 'Perf. Score', value: `${user.performanceScore || 0}%`, icon: BarChart3, color: 'text-purple-400', bg: 'bg-purple-400/10' },
          ].map((item, idx) => (
            <motion.div
              key={item.label}
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ delay: idx * 0.05 }}
              className="bg-brand-card p-4 rounded-2xl border border-brand-border flex flex-col items-center gap-2"
            >
              <div className={cn("w-10 h-10 rounded-xl flex items-center justify-center", item.bg, item.color)}>
                <item.icon size={20} />
              </div>
              <div className="text-center">
                <div className="text-lg font-bold text-white">{item.value}</div>
                <div className="text-[10px] font-bold uppercase text-brand-text-muted tracking-tighter">{item.label}</div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>

      <div className="space-y-6">
        <div className="flex items-center justify-between px-2">
          <h2 className="text-sm font-bold uppercase tracking-widest text-brand-text-muted">Personal Information</h2>
          {!isEditing ? (
            <button 
              onClick={() => setIsEditing(true)}
              className="text-xs font-bold text-brand-accent hover:underline"
            >
              Edit Details
            </button>
          ) : (
            <button 
              onClick={handleSave}
              className="flex items-center gap-2 text-xs font-bold text-emerald-400 hover:underline"
            >
              <Save size={14} />
              Save Changes
            </button>
          )}
        </div>

        <div className="bg-brand-card rounded-3xl border border-brand-border overflow-hidden divide-y divide-brand-border">
          <div className="p-6 grid grid-cols-1 md:grid-cols-2 gap-6">
            {/* Name Field */}
            <div className="space-y-2">
              <label className="text-xs font-bold text-brand-text-muted uppercase tracking-wider flex items-center gap-2">
                <User size={14} />
                Full Name
              </label>
              {isEditing ? (
                <input 
                  type="text"
                  value={formData.displayName}
                  onChange={(e) => setFormData({ ...formData, displayName: e.target.value })}
                  className="w-full bg-brand-bg border border-brand-border rounded-xl px-4 py-2 text-sm focus:outline-none focus:ring-1 focus:ring-brand-accent"
                />
              ) : (
                <p className="text-sm font-medium text-white px-1">{user.displayName}</p>
              )}
            </div>

            {/* Email Field (Read Only) */}
            <div className="space-y-2">
              <label className="text-xs font-bold text-brand-text-muted uppercase tracking-wider flex items-center gap-2">
                <Mail size={14} />
                Email Address
              </label>
              <p className="text-sm font-medium text-white/50 px-1">{user.email}</p>
            </div>

            {/* Phone Field */}
            <div className="space-y-2">
              <label className="text-xs font-bold text-brand-text-muted uppercase tracking-wider flex items-center gap-2">
                <Phone size={14} />
                Phone Number
              </label>
              {isEditing ? (
                <input 
                  type="tel"
                  placeholder="+1 234 567 890"
                  value={formData.phone}
                  onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                  className="w-full bg-brand-bg border border-brand-border rounded-xl px-4 py-2 text-sm focus:outline-none focus:ring-1 focus:ring-brand-accent"
                />
              ) : (
                <p className="text-sm font-medium text-white px-1">{user.phone || 'Not provided'}</p>
              )}
            </div>

            {/* Branch Field */}
            <div className="space-y-2">
              <label className="text-xs font-bold text-brand-text-muted uppercase tracking-wider flex items-center gap-2">
                <Building2 size={14} />
                Branch / Department
              </label>
              {isEditing ? (
                <input 
                  type="text"
                  placeholder="e.g. Computer Science"
                  value={formData.branch}
                  onChange={(e) => setFormData({ ...formData, branch: e.target.value })}
                  className="w-full bg-brand-bg border border-brand-border rounded-xl px-4 py-2 text-sm focus:outline-none focus:ring-1 focus:ring-brand-accent"
                />
              ) : (
                <p className="text-sm font-medium text-white px-1">{user.branch || 'Not provided'}</p>
              )}
            </div>
          </div>

          <div className="p-4 bg-brand-bg/50">
            <button 
              onClick={onLogout}
              className="w-full p-4 flex items-center justify-between hover:bg-rose-500/10 transition-colors text-rose-400 rounded-2xl group"
            >
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 bg-rose-500/20 rounded-xl flex items-center justify-center group-hover:scale-110 transition-transform">
                  <LogOut size={20} />
                </div>
                <span className="text-sm font-bold">Sign Out of Account</span>
              </div>
              <ChevronRight size={18} className="opacity-50" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}

function cn(...inputs: any[]) {
  return inputs.filter(Boolean).join(' ');
}
