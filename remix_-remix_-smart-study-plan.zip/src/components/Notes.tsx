import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Search, Plus, FileText, Sparkles, Trash2, Link as LinkIcon, ExternalLink, X, ArrowLeft, Youtube, Globe } from 'lucide-react';
import { StudyNote } from '@/src/types';
import { cn } from '@/src/lib/utils';

interface NotesProps {
  notes: StudyNote[];
  onAddNote: () => void;
  onDeleteNote: (id: string) => void;
  onSummarize: (id: string) => void;
  onUpdateNote: (id: string, updates: Partial<StudyNote>) => void;
  onBack: () => void;
  onFindResources: (id: string) => void;
}

export default function Notes({ notes, onAddNote, onDeleteNote, onSummarize, onUpdateNote, onBack, onFindResources }: NotesProps) {
  const [search, setSearch] = useState('');
  const [addingLinkTo, setAddingLinkTo] = useState<string | null>(null);
  const [newLink, setNewLink] = useState('');

  const filteredNotes = notes.filter(n => 
    n.title.toLowerCase().includes(search.toLowerCase()) || 
    n.subject.toLowerCase().includes(search.toLowerCase())
  );

  const handleAddLink = (note: StudyNote) => {
    if (!newLink.trim()) return;
    
    // Simple URL validation
    let url = newLink.trim();
    if (!url.startsWith('http://') && !url.startsWith('https://')) {
      url = 'https://' + url;
    }

    const updatedLinks = [...(note.links || []), url];
    onUpdateNote(note.id, { links: updatedLinks });
    setNewLink('');
    setAddingLinkTo(null);
  };

  const removeLink = (note: StudyNote, linkToRemove: string) => {
    const updatedLinks = note.links.filter(l => l !== linkToRemove);
    onUpdateNote(note.id, { links: updatedLinks });
  };

  const getLinkIcon = (url: string) => {
    if (url.includes('youtube.com') || url.includes('youtu.be')) return <Youtube size={14} className="text-rose-500" />;
    return <Globe size={14} className="text-indigo-500" />;
  };

  return (
    <div className="p-6 space-y-6">
      <header className="flex justify-between items-center">
        <div className="flex items-center gap-3">
          <button 
            onClick={onBack}
            className="p-2 hover:bg-slate-100 rounded-xl text-slate-500 transition-colors"
          >
            <ArrowLeft size={20} />
          </button>
          <h1 className="text-2xl font-bold tracking-tight">My Notes</h1>
        </div>
        <button 
          onClick={onAddNote}
          className="bg-indigo-600 text-white p-2 rounded-xl shadow-lg shadow-indigo-200"
        >
          <Plus size={20} />
        </button>
      </header>

      <div className="relative">
        <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
        <input 
          type="text"
          placeholder="Search notes or subjects..."
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          className="w-full bg-white border border-slate-100 rounded-2xl py-3 pl-12 pr-4 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500/20 transition-all"
        />
      </div>

      <div className="grid grid-cols-1 gap-4">
        {filteredNotes.length === 0 ? (
          <div className="text-center py-12 bg-white rounded-3xl border border-dashed border-slate-200">
            <FileText className="mx-auto text-slate-300 mb-2" size={32} />
            <p className="text-slate-400 text-sm">No notes found. Start writing!</p>
          </div>
        ) : (
          filteredNotes.map((note, idx) => (
            <motion.div
              key={note.id}
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ delay: idx * 0.05 }}
              className="bg-white p-5 rounded-3xl shadow-sm border border-slate-100 space-y-3 relative group"
            >
              <div className="flex justify-between items-start">
                <div className="space-y-1">
                  <span className="text-[10px] font-bold uppercase tracking-widest text-indigo-500 bg-indigo-50 px-2 py-0.5 rounded-md">
                    {note.subject}
                  </span>
                  <h3 className="font-bold text-slate-800">{note.title}</h3>
                </div>
                <div className="flex gap-1">
                  <button 
                    onClick={() => onSummarize(note.id)}
                    className="p-2 text-indigo-600 hover:bg-indigo-50 rounded-xl transition-colors"
                    title="Summarize with AI"
                  >
                    <Sparkles size={18} />
                  </button>
                  <button 
                    onClick={() => onFindResources(note.id)}
                    className="p-2 text-rose-600 hover:bg-rose-50 rounded-xl transition-colors"
                    title="Find Related Videos"
                  >
                    <Youtube size={18} />
                  </button>
                  <button 
                    onClick={() => setAddingLinkTo(addingLinkTo === note.id ? null : note.id)}
                    className={cn(
                      "p-2 rounded-xl transition-colors",
                      addingLinkTo === note.id ? "bg-indigo-600 text-white" : "text-indigo-400 hover:bg-indigo-50"
                    )}
                    title="Add External Link"
                  >
                    <LinkIcon size={18} />
                  </button>
                  <button 
                    onClick={() => onDeleteNote(note.id)}
                    className="p-2 text-slate-400 hover:text-rose-500 hover:bg-rose-50 rounded-xl transition-colors"
                  >
                    <Trash2 size={18} />
                  </button>
                </div>
              </div>
              
              <p className="text-slate-500 text-xs line-clamp-3 leading-relaxed">
                {note.content}
              </p>

              <AnimatePresence>
                {addingLinkTo === note.id && (
                  <motion.div 
                    initial={{ opacity: 0, height: 0 }}
                    animate={{ opacity: 1, height: 'auto' }}
                    exit={{ opacity: 0, height: 0 }}
                    className="overflow-hidden"
                  >
                    <div className="flex gap-2 mt-2">
                      <input 
                        type="text"
                        placeholder="Paste URL here..."
                        value={newLink}
                        onChange={(e) => setNewLink(e.target.value)}
                        onKeyPress={(e) => e.key === 'Enter' && handleAddLink(note)}
                        className="flex-1 bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs focus:outline-none focus:ring-2 focus:ring-indigo-500/20"
                        autoFocus
                      />
                      <button 
                        onClick={() => handleAddLink(note)}
                        className="bg-indigo-600 text-white px-3 py-2 rounded-xl text-xs font-bold"
                      >
                        Add
                      </button>
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>

              {note.links && note.links.length > 0 && (
                <div className="flex flex-wrap gap-2 mt-2">
                  {note.links.map((link, lIdx) => (
                    <div 
                      key={lIdx}
                      className="flex items-center gap-1 bg-slate-50 border border-slate-100 px-2 py-1 rounded-lg group/link"
                    >
                      <a 
                        href={link} 
                        target="_blank" 
                        rel="noopener noreferrer"
                        className="text-[10px] text-indigo-600 hover:underline flex items-center gap-1"
                      >
                        {getLinkIcon(link)}
                        <span className="max-w-[120px] truncate">{link.replace(/^https?:\/\//, '')}</span>
                      </a>
                      <button 
                        onClick={() => removeLink(note, link)}
                        className="text-slate-300 hover:text-rose-500 opacity-0 group-hover/link:opacity-100 transition-opacity"
                      >
                        <X size={10} />
                      </button>
                    </div>
                  ))}
                </div>
              )}

              {note.summary && (
                <div className="mt-3 p-3 bg-indigo-50/50 rounded-2xl border border-indigo-100/50">
                  <div className="flex items-center gap-1.5 mb-1">
                    <Sparkles size={12} className="text-indigo-600" />
                    <span className="text-[10px] font-bold uppercase text-indigo-600">AI Summary</span>
                  </div>
                  <p className="text-[11px] text-indigo-900/70 leading-relaxed italic">
                    {note.summary}
                  </p>
                </div>
              )}

              <div className="pt-2 flex items-center justify-between text-[10px] text-slate-400 font-medium">
                <span>{new Date(note.updatedAt).toLocaleDateString()}</span>
                <div className="flex gap-2">
                  {note.pdfUrls.length > 0 && <span>{note.pdfUrls.length} PDFs</span>}
                  {note.links.length > 0 && <span>{note.links.length} Links</span>}
                </div>
              </div>
            </motion.div>
          ))
        )}
      </div>
    </div>
  );
}
