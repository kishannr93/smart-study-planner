import { GoogleGenAI, Type } from "@google/genai";

const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY || '' });

export const geminiService = {
  async chat(message: string, history: { role: 'user' | 'model', parts: { text: string }[] }[] = []) {
    try {
      const response = await ai.models.generateContent({
        model: "gemini-3-flash-preview",
        contents: [
          ...history.map(h => ({ role: h.role, parts: h.parts })),
          { role: 'user', parts: [{ text: message }] }
        ],
        config: {
          systemInstruction: "You are a helpful AI Study Assistant. Your goal is to help students with their academic queries, explain complex concepts simply, and provide study tips. Keep your answers concise, encouraging, and accurate. Use markdown for formatting.",
        }
      });
      return response.text || "I'm sorry, I couldn't generate a response.";
    } catch (error) {
      console.error("Gemini Chat Error:", error);
      throw error;
    }
  },

  async summarizeNote(content: string) {
    try {
      const response = await ai.models.generateContent({
        model: "gemini-3-flash-preview",
        contents: `Summarize the following study notes into a concise, bulleted summary of key points:\n\n${content}`,
        config: {
          systemInstruction: "You are an expert at summarizing academic content. Provide a clear, structured summary.",
        }
      });
      return response.text || "Could not generate summary.";
    } catch (error) {
      console.error("Gemini Summary Error:", error);
      throw error;
    }
  },

  async getCareerAdvice(interests: string[], skills: string[]) {
    try {
      const response = await ai.models.generateContent({
        model: "gemini-3-flash-preview",
        contents: `Based on these interests: ${interests.join(', ')} and skills: ${skills.join(', ')}, suggest 3 career paths with roadmaps.`,
        config: {
          responseMimeType: "application/json",
          responseSchema: {
            type: Type.ARRAY,
            items: {
              type: Type.OBJECT,
              properties: {
                title: { type: Type.STRING },
                description: { type: Type.STRING },
                roadmap: { type: Type.ARRAY, items: { type: Type.STRING } },
                requiredSkills: { type: Type.ARRAY, items: { type: Type.STRING } },
                trending: { type: Type.BOOLEAN }
              },
              required: ["title", "description", "roadmap", "requiredSkills", "trending"]
            }
          }
        }
      });
      return JSON.parse(response.text || "[]");
    } catch (error) {
      console.error("Gemini Career Advice Error:", error);
      throw error;
    }
  },

  async getCareerDeepDive(careerTitle: string) {
    try {
      const response = await ai.models.generateContent({
        model: "gemini-3-flash-preview",
        contents: `Provide a deep dive analysis for the career path: "${careerTitle}". 
        Include salary ranges, typical day-to-day tasks, top companies hiring, recommended certifications, future outlook, and learning resources.`,
        config: {
          responseMimeType: "application/json",
          responseSchema: {
            type: Type.OBJECT,
            properties: {
              salaryRange: { type: Type.STRING },
              dayToDay: { type: Type.ARRAY, items: { type: Type.STRING } },
              topCompanies: { type: Type.ARRAY, items: { type: Type.STRING } },
              certifications: { type: Type.ARRAY, items: { type: Type.STRING } },
              futureOutlook: { type: Type.STRING },
              learningResources: { 
                type: Type.ARRAY, 
                items: { 
                  type: Type.OBJECT,
                  properties: {
                    title: { type: Type.STRING },
                    url: { type: Type.STRING }
                  },
                  required: ["title", "url"]
                } 
              }
            },
            required: ["salaryRange", "dayToDay", "topCompanies", "certifications", "futureOutlook", "learningResources"]
          }
        }
      });
      return JSON.parse(response.text || "{}");
    } catch (error) {
      console.error("Gemini Career Deep Dive Error:", error);
      throw error;
    }
  },

  async generateQuiz(subject: string, topic: string, context?: string) {
    try {
      const prompt = context 
        ? `Generate a 5-question multiple choice quiz based on the following study context:
        
        CONTEXT:
        ${context}
        
        The quiz should be challenging and cover the key concepts discussed in the context. The subject is ${subject}.`
        : `Generate a 5-question multiple choice quiz about ${topic} in the subject of ${subject}.`;

      const response = await ai.models.generateContent({
        model: "gemini-3-flash-preview",
        contents: prompt,
        config: {
          responseMimeType: "application/json",
          responseSchema: {
            type: Type.OBJECT,
            properties: {
              title: { type: Type.STRING },
              subject: { type: Type.STRING },
              questions: {
                type: Type.ARRAY,
                items: {
                  type: Type.OBJECT,
                  properties: {
                    question: { type: Type.STRING },
                    options: { type: Type.ARRAY, items: { type: Type.STRING } },
                    correctAnswer: { type: Type.INTEGER, description: "Index of the correct option (0-3)" },
                    explanation: { type: Type.STRING }
                  },
                  required: ["question", "options", "correctAnswer", "explanation"]
                }
              }
            },
            required: ["title", "subject", "questions"]
          }
        }
      });
      return JSON.parse(response.text || "{}");
    } catch (error) {
      console.error("Gemini Quiz Generation Error:", error);
      throw error;
    }
  },

  async findResources(content: string, subject: string) {
    try {
      const response = await ai.models.generateContent({
        model: "gemini-3-flash-preview",
        contents: `Based on the following study notes about ${subject}, suggest 3-5 high-quality YouTube search links or educational resource URLs (like Khan Academy, Coursera, or official documentation) that would help the student learn more about this topic.
        
        NOTES:
        ${content}`,
        config: {
          responseMimeType: "application/json",
          responseSchema: {
            type: Type.ARRAY,
            items: {
              type: Type.OBJECT,
              properties: {
                title: { type: Type.STRING, description: "Title of the resource or search query" },
                url: { type: Type.STRING, description: "The direct URL or a YouTube search URL" },
                type: { type: Type.STRING, enum: ["youtube", "article", "course", "other"] }
              },
              required: ["title", "url", "type"]
            }
          }
        }
      });
      return JSON.parse(response.text || "[]");
    } catch (error) {
      console.error("Gemini Resource Discovery Error:", error);
      throw error;
    }
  }
};
