export interface ChatMessage {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  timestamp: string; // ISO date
}

export interface UserProfile {
  uid: string;
  email: string;
  displayName: string;
  photoURL: string;
  phone?: string;
  branch?: string;
  studyGoals: string[];
  interests: string[];
  streak: number;
  studyHours?: number;
  performanceScore?: number;
  lastActive: string; // ISO date
  role: 'student' | 'admin';
}

export interface StudyTask {
  id: string;
  userId: string;
  title: string;
  subject: string;
  deadline: string; // ISO date
  completed: boolean;
  priority: 'low' | 'medium' | 'high';
  createdAt: string;
}

export interface StudyNote {
  id: string;
  userId: string;
  title: string;
  subject: string;
  content: string; // Markdown
  summary?: string;
  links: string[];
  pdfUrls: string[];
  createdAt: string;
  updatedAt: string;
}

export interface CareerPath {
  id: string;
  userId: string;
  title: string;
  description: string;
  roadmap: string[];
  requiredSkills: string[];
  trending: boolean;
  createdAt: string;
}

export interface CareerDeepDive {
  salaryRange: string;
  dayToDay: string[];
  topCompanies: string[];
  certifications: string[];
  futureOutlook: string;
  learningResources: { title: string; url: string }[];
}

export interface Quiz {
  id: string;
  userId: string;
  title: string;
  subject: string;
  questions: {
    question: string;
    options: string[];
    correctAnswer: number;
    explanation: string;
  }[];
  score?: number;
  createdAt: string;
}
