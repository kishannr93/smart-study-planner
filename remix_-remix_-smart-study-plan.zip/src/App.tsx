/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, lazy, Suspense } from 'react';
import { onAuthStateChanged, signInWithPopup, signOut, User as FirebaseUser } from 'firebase/auth';
import { 
  collection, 
  doc, 
  setDoc, 
  getDoc, 
  updateDoc, 
  deleteDoc, 
  onSnapshot, 
  query, 
  where, 
  orderBy,
  addDoc
} from 'firebase/firestore';
import { auth, db, googleProvider, handleFirestoreError, OperationType } from './firebase';
import { UserProfile, StudyTask, StudyNote, CareerPath, Quiz, ChatMessage } from './types';
import { geminiService } from './services/geminiService';
import Layout from './components/Layout';
import Dashboard from './components/Dashboard';
import Login from './components/Login';
import ErrorBoundary from './components/ErrorBoundary';
import { Toaster, toast } from 'sonner';
import { Loader2 } from 'lucide-react';

// Lazy load heavy components
const Planner = lazy(() => import('./components/Planner'));
const Notes = lazy(() => import('./components/Notes'));
const Career = lazy(() => import('./components/Career'));
const AIChat = lazy(() => import('./components/AIChat'));
const Profile = lazy(() => import('./components/Profile'));
const QuizSection = lazy(() => import('./components/QuizSection'));

const LoadingFallback = () => (
  <div className="h-[calc(100vh-80px)] flex flex-col items-center justify-center bg-slate-50 space-y-4">
    <div className="relative">
      <div className="w-16 h-16 border-4 border-indigo-100 rounded-full" />
      <div className="absolute top-0 left-0 w-16 h-16 border-4 border-indigo-600 border-t-transparent rounded-full animate-spin" />
    </div>
    <div className="text-center">
      <p className="text-slate-800 font-bold">Loading Tool...</p>
      <p className="text-slate-400 text-xs">Preparing your AI-powered workspace</p>
    </div>
  </div>
);

export default function App() {
  const [user, setUser] = useState<FirebaseUser | null>(null);
  const [profile, setProfile] = useState<UserProfile | null>(null);
  const [activeTab, setActiveTab] = useState('home');
  const [isLoading, setIsLoading] = useState(true);
  const [tasks, setTasks] = useState<StudyTask[]>([]);
  const [notes, setNotes] = useState<StudyNote[]>([]);
  const [careerPaths, setCareerPaths] = useState<CareerPath[]>([]);
  const [quizzes, setQuizzes] = useState<Quiz[]>([]);
  const [chatHistory, setChatHistory] = useState<ChatMessage[]>([
    {
      id: '1',
      role: 'assistant',
      content: "Hi! I'm your AI Study Assistant. How can I help you today? I can explain concepts, summarize topics, or help with your study plan.",
      timestamp: new Date().toISOString()
    }
  ]);

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, async (firebaseUser) => {
      setUser(firebaseUser);
      if (firebaseUser) {
        await ensureUserProfile(firebaseUser);
      } else {
        setProfile(null);
        setTasks([]);
        setNotes([]);
        setCareerPaths([]);
        setQuizzes([]);
      }
      setIsLoading(false);
    });
    return () => unsubscribe();
  }, []);

  useEffect(() => {
    if (!user) return;

    const tasksQuery = query(collection(db, `users/${user.uid}/tasks`), orderBy('createdAt', 'desc'));
    const unsubTasks = onSnapshot(tasksQuery, (snapshot) => {
      setTasks(snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as StudyTask)));
    }, (err) => handleFirestoreError(err, OperationType.LIST, `users/${user.uid}/tasks`));

    const notesQuery = query(collection(db, `users/${user.uid}/notes`), orderBy('updatedAt', 'desc'));
    const unsubNotes = onSnapshot(notesQuery, (snapshot) => {
      setNotes(snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as StudyNote)));
    }, (err) => handleFirestoreError(err, OperationType.LIST, `users/${user.uid}/notes`));

    const careerQuery = query(collection(db, `users/${user.uid}/careerPaths`), orderBy('createdAt', 'desc'));
    const unsubCareer = onSnapshot(careerQuery, (snapshot) => {
      setCareerPaths(snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as CareerPath)));
    }, (err) => handleFirestoreError(err, OperationType.LIST, `users/${user.uid}/careerPaths`));

    const quizQuery = query(collection(db, `users/${user.uid}/quizzes`), orderBy('createdAt', 'desc'));
    const unsubQuizzes = onSnapshot(quizQuery, (snapshot) => {
      setQuizzes(snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as Quiz)));
    }, (err) => handleFirestoreError(err, OperationType.LIST, `users/${user.uid}/quizzes`));

    return () => {
      unsubTasks();
      unsubNotes();
      unsubCareer();
      unsubQuizzes();
    };
  }, [user]);

  const ensureUserProfile = async (firebaseUser: FirebaseUser) => {
    const userDoc = doc(db, 'users', firebaseUser.uid);
    const snap = await getDoc(userDoc);
    
    if (!snap.exists()) {
      const newProfile: UserProfile = {
        uid: firebaseUser.uid,
        email: firebaseUser.email || '',
        displayName: firebaseUser.displayName || 'Student',
        photoURL: firebaseUser.photoURL || '',
        studyGoals: [],
        interests: [],
        streak: 1,
        studyHours: 0,
        performanceScore: 0,
        lastActive: new Date().toISOString(),
        role: 'student'
      };
      await setDoc(userDoc, newProfile);
      setProfile(newProfile);
    } else {
      setProfile(snap.data() as UserProfile);
    }
  };

  const handleLogin = async () => {
    try {
      await signInWithPopup(auth, googleProvider);
      toast.success('Welcome to Smart Study!');
    } catch (error) {
      console.error('Login error:', error);
      toast.error('Failed to login. Please try again.');
    }
  };

  const handleLogout = async () => {
    try {
      await signOut(auth);
      toast.success('Logged out successfully');
    } catch (error) {
      console.error('Logout error:', error);
    }
  };

  const handleUpdateProfile = async (updates: Partial<UserProfile>) => {
    if (!user) return;
    try {
      await updateDoc(doc(db, 'users', user.uid), updates);
      setProfile(prev => prev ? { ...prev, ...updates } : null);
      toast.success('Profile updated!');
    } catch (error) {
      handleFirestoreError(error, OperationType.UPDATE, `users/${user.uid}`);
    }
  };

  const handleAddTask = async (task: Partial<StudyTask>) => {
    if (!user) return;
    try {
      const newTask: Omit<StudyTask, 'id'> = {
        userId: user.uid,
        title: task.title || 'New Study Session',
        subject: task.subject || 'General',
        deadline: task.deadline || new Date().toISOString(),
        completed: false,
        priority: task.priority || 'medium',
        createdAt: new Date().toISOString()
      };
      await addDoc(collection(db, `users/${user.uid}/tasks`), newTask);
      toast.success('Task added!');
    } catch (error) {
      handleFirestoreError(error, OperationType.CREATE, `users/${user.uid}/tasks`);
    }
  };

  const handleAddNote = async () => {
    if (!user) return;
    try {
      const newNote: Omit<StudyNote, 'id'> = {
        userId: user.uid,
        title: 'New Note',
        subject: 'General',
        content: 'Start typing your notes here...',
        links: [],
        pdfUrls: [],
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
      };
      await addDoc(collection(db, `users/${user.uid}/notes`), newNote);
      toast.success('Note created!');
    } catch (error) {
      handleFirestoreError(error, OperationType.CREATE, `users/${user.uid}/notes`);
    }
  };

  const handleDeleteNote = async (id: string) => {
    if (!user) return;
    try {
      await deleteDoc(doc(db, `users/${user.uid}/notes`, id));
      toast.success('Note deleted');
    } catch (error) {
      handleFirestoreError(error, OperationType.DELETE, `users/${user.uid}/notes/${id}`);
    }
  };

  const handleSummarizeNote = async (id: string) => {
    if (!user) return;
    const note = notes.find(n => n.id === id);
    if (!note) return;

    toast.promise(geminiService.summarizeNote(note.content), {
      loading: 'AI is summarizing...',
      success: async (summary) => {
        await updateDoc(doc(db, `users/${user.uid}/notes`, id), {
          summary,
          updatedAt: new Date().toISOString()
        });
        return 'Summary generated!';
      },
      error: 'Failed to generate summary'
    });
  };

  const handleFindResources = async (id: string) => {
    if (!user) return;
    const note = notes.find(n => n.id === id);
    if (!note) return;

    toast.promise(geminiService.findResources(note.content, note.subject), {
      loading: 'AI is finding related YouTube videos and resources...',
      success: async (resources) => {
        const currentLinks = note.links || [];
        const newLinks = resources.map((r: any) => r.url);
        const combinedLinks = Array.from(new Set([...currentLinks, ...newLinks]));
        
        await updateDoc(doc(db, `users/${user.uid}/notes`, id), {
          links: combinedLinks,
          updatedAt: new Date().toISOString()
        });
        return `Added ${resources.length} related resources!`;
      },
      error: 'Failed to find resources'
    });
  };

  const handleGetCareerAdvice = async () => {
    if (!user || !profile) return;
    
    toast.promise(geminiService.getCareerAdvice(profile.interests, profile.studyGoals), {
      loading: 'AI is analyzing career paths...',
      success: async (paths) => {
        for (const path of paths) {
          await addDoc(collection(db, `users/${user.uid}/careerPaths`), {
            ...path,
            userId: user.uid,
            createdAt: new Date().toISOString()
          });
        }
        return 'Career paths generated!';
      },
      error: 'Failed to get career advice'
    });
  };

  const handleGenerateQuiz = async (subject: string) => {
    if (!user) return;
    
    // Gather context from recent chat history and notes
    const recentChat = chatHistory
      .filter(m => m.role === 'user' || m.role === 'assistant')
      .slice(-10)
      .map(m => `${m.role}: ${m.content}`)
      .join('\n');
    
    const recentNotes = notes
      .slice(0, 3)
      .map(n => `Note (${n.title}): ${n.content}`)
      .join('\n\n');

    const context = `RECENT CHAT HISTORY:\n${recentChat}\n\nRECENT NOTES:\n${recentNotes}`;
    
    toast.promise(geminiService.generateQuiz(subject, 'Recent Discussions', context), {
      loading: 'Generating personalized AI Quiz...',
      success: async (quizData) => {
        await addDoc(collection(db, `users/${user.uid}/quizzes`), {
          ...quizData,
          userId: user.uid,
          createdAt: new Date().toISOString()
        });
        return 'Personalized quiz ready!';
      },
      error: 'Failed to generate quiz'
    });
  };

  const handleSendMessage = async (message: string) => {
    const userMsg: ChatMessage = {
      id: Date.now().toString(),
      role: 'user',
      content: message,
      timestamp: new Date().toISOString()
    };
    setChatHistory(prev => [...prev, userMsg]);
    
    try {
      const history = chatHistory.map(m => ({
        role: m.role === 'assistant' ? 'model' as const : 'user' as const,
        parts: [{ text: m.content }]
      }));
      
      const response = await geminiService.chat(message, history);
      
      const assistantMsg: ChatMessage = {
        id: (Date.now() + 1).toString(),
        role: 'assistant',
        content: response,
        timestamp: new Date().toISOString()
      };
      setChatHistory(prev => [...prev, assistantMsg]);
      return response;
    } catch (error) {
      console.error('Chat error:', error);
      throw error;
    }
  };

  const handleUpdateNote = async (id: string, updates: Partial<StudyNote>) => {
    if (!user) return;
    try {
      await updateDoc(doc(db, `users/${user.uid}/notes`, id), {
        ...updates,
        updatedAt: new Date().toISOString()
      });
      toast.success('Note updated!');
    } catch (error) {
      handleFirestoreError(error, OperationType.UPDATE, `users/${user.uid}/notes/${id}`);
    }
  };

  const handleBack = () => setActiveTab('home');

  const renderContent = () => {
    return (
      <Suspense fallback={<LoadingFallback />}>
        {(() => {
          switch (activeTab) {
            case 'home':
              return <Dashboard onSelectTool={setActiveTab} />;
            case 'planner':
              return <Planner tasks={tasks} onAddTask={handleAddTask} onBack={handleBack} />;
            case 'notes':
              return <Notes notes={notes} onAddNote={handleAddNote} onDeleteNote={handleDeleteNote} onSummarize={handleSummarizeNote} onUpdateNote={handleUpdateNote} onBack={handleBack} onFindResources={handleFindResources} />;
            case 'career':
              return <Career careerPaths={careerPaths} onGetAdvice={handleGetCareerAdvice} onBack={handleBack} />;
            case 'chat':
              return <AIChat messages={chatHistory} onSendMessage={handleSendMessage} onBack={handleBack} />;
            case 'profile':
              return profile ? <Profile user={profile} tasks={tasks} onLogout={handleLogout} onUpdateProfile={handleUpdateProfile} onBack={handleBack} /> : null;
            case 'practice':
              return <QuizSection quizzes={quizzes} onGenerateQuiz={handleGenerateQuiz} onBack={handleBack} />;
            default:
              return <Dashboard onSelectTool={setActiveTab} />;
          }
        })()}
      </Suspense>
    );
  };

  if (isLoading) {
    return (
      <div className="h-screen flex items-center justify-center bg-slate-50">
        <div className="w-12 h-12 border-4 border-indigo-600 border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }

  if (!user) {
    return <Login onLogin={handleLogin} isLoading={false} />;
  }

  return (
    <ErrorBoundary>
      <Layout 
        activeTab={activeTab} 
        setActiveTab={setActiveTab}
        userName={profile?.displayName}
        onLogout={handleLogout}
      >
        {renderContent()}
      </Layout>
      <Toaster position="top-center" richColors />
    </ErrorBoundary>
  );
}

